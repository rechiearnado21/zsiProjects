window.location.replace( base_url + "page/signin");
localStorage.removeItem("menuItems");
localStorage.removeItem("publicTemplates");
    